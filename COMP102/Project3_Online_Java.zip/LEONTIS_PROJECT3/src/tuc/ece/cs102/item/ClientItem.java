package tuc.ece.cs102.item;

import tuc.ece.cs102.company.Client;
import tuc.ece.cs102.list.Item;

public class ClientItem  extends Item{
	
	private Client client;
	
	public ClientItem(Client iClient) {
		client=iClient;
	}
	public Object key() {
		return client.getAm();
	}
	public boolean equals(Item o) {
		return key().equals(o.key());
	}
	public boolean less(Item o) {
		if(((String) key()).compareTo((String) o.key())<0)
				return true;
		
		return false;
	}
	public String toString() {
		return client.toString();
	}
	public void print() {
		client.print();
	}
	public Object getData() {
		return this.client;
	}
	public Object vehId() {
		return client.getAm();
	}
	public Object clId() {
		return client.getAm();
	}
	

}
