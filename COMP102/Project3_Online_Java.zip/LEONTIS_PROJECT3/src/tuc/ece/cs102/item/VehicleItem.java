package tuc.ece.cs102.item;


import tuc.ece.cs102.company.Vehicle;
import tuc.ece.cs102.list.Item;

public class VehicleItem extends Item {
	
	private Vehicle vehicle;
	
	public VehicleItem(Vehicle iVehicle) {
		vehicle=iVehicle;
	}
	public Object key() {
		return vehicle.getAm();
	}
	public boolean equals(Item o) {
		return key().equals(o.key());
	}
	public boolean less(Item o) {
		if(((String) key()).compareTo((String) o.key()) <0) 
		return true;
		
		return false;
	}
	public String toString() {
		return vehicle.toString();
	}
	public void print() {
		vehicle.print();
	}
	public Object getData() {
		return this.vehicle;
	}
	public Object clId() {
		return vehicle.getAm();
	}
	public Object vehId() {
		return vehicle.getAm();
	}

}
