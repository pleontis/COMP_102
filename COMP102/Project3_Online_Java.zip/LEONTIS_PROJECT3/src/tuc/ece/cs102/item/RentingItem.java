package tuc.ece.cs102.item;

import tuc.ece.cs102.company.Renting;
import tuc.ece.cs102.list.Item;

public class RentingItem extends Item{
	
	private Renting renting;
	
	public RentingItem(Renting iRenting) {
	renting=iRenting;	
	}
	
	public Object key() {
		return renting.getCode();
	}
	public boolean equals(Item o) {
		return key().equals(o.key());
	}
	public boolean less(Item o) {
		if(((Integer) key()).compareTo((Integer) o.key()) <0)
			return true;
		
		return false;
	}
	public void print() {
		renting.print();
	}
	public String toString() {
		return renting.toString();
	}
	public Object getData() {
		return this.renting;
	}
	public Object vehId() {
		return renting.getVehicle();
	}
	public Object clId() {
		return renting.getClient();
	}
}
