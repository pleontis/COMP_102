package tuc.ece.cs102.list;

public class List {
	protected Node head;
	protected int lenght;
	
	public List() {
		head=null;
		lenght=0;
	}
	public Node getHead() {
		return head;
	}
	public boolean isEmpty() {
		return head==null;
	}
	public Node insert(Item a) {
		lenght++;
		head=new Node(a);
		return head;
	}
	public int getLenght() {
		return lenght;
	}
	public void clearList() {
		head=null;
		lenght=0;
	}
	public void printList() {
		int i=0;
		for(Node tmp=head;tmp!=null;tmp=tmp.getNext()) {
			
			System.out.println(i+")"); 
			tmp.print();
			i++;
		}
		
		//We have an empty list
		if(i==0) { 			
			System.out.println("Empty list !!!");
		}
	}
		
	public Node search(Item a) {
		for(Node tmp=head;tmp!=null;tmp=tmp.getNext()) {
			
			if(a.equals(tmp.getData())){
				return tmp;
			}
		}
		//Node wasn't found
		return null; 
	}
	public Node delete(Item a) {
		Node n1=head, n2=head;
		
		while(n1!=null && !a.equals(n1.getData())) {
			n2=n1;
			n1=n1.getNext();
			}
			
			if(n1!=null) {
				lenght--;
				if(n1!=n2) {
				n2.setNext(n1.getNext());
				}
				//n1 is head Node
				else {
					head=head.getNext();
				}
			}
			n1.setNext(null);
			return head;
	}

	public Item removeFirst() {
		Node tmp=head;
		if(head!=null) {
			lenght--;
			head=head.getNext();
			tmp.setNext(null);
			
			return tmp.getData();
		}
		//Empty list
		else
			return null;
	}
}