package tuc.ece.cs102.list;

public abstract class Item {
	public abstract boolean equals(Item k);
	public abstract boolean less(Item k);
	public abstract Object key();
	public abstract void print();
	public abstract Object getData();
	public abstract Object vehId();
	public abstract Object clId();
}
