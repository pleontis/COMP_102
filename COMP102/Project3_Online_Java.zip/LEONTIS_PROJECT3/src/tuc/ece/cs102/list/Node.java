package tuc.ece.cs102.list;

public class Node {
	private Item data;
	private Node next;
	
	public Node(Item dat) {
		data=dat;
	}
	public Node(Item dat, Node n) {
		data=dat;
		next=n;
	}
	public void print(){
		data.print();
	}
	public Item getData() {
		return data;
	}
	public void setData(Item data) {
		this.data=data;
	}
	public void setNext(Node a) {
		next=a;
	}
	public Node getNext() {
		return next;
	}

}
