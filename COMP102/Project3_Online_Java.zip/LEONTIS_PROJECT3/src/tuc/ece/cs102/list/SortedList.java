package tuc.ece.cs102.list;


public class SortedList extends List {
	
	public Node insert(Item a) {
		Node tmp= new Node(a);
		lenght++;
		
		Node n1=head, n2=head;
		while(n1!=null && n1.getData().less(a)) {
			n2=n1;
			n1=n1.getNext();
		}
		if(n1!=n2) {
			tmp.setNext(n1);
			n2.setNext(tmp);
		}
		//n1 is head Node
		else {
			tmp.setNext(n1);
			head=tmp;
		}
			
		return head;
	}
public void printAllInHierarchy(String className){
		
		Node tmp = head;
				
		try{
					
		while (tmp!=null){
						
		Item item = tmp.getData();				
						
		if (Class.forName(className).isInstance(item.getData())){
							
		item.print();
						
		}
						
		tmp = tmp.getNext();
					
		}
				
		}catch (ClassNotFoundException ex){
					
		System.out.println("This class "+className+" does not exist...");
				
			}		
			
		}
}
