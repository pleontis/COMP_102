package tuc.ece.cs102.company;

public abstract class Client {
	protected String name;
	protected String am;
	protected String phoneNumber;
	protected String cityLiving;
	protected String countryLiving;
	
	
	public Client(String n,String id,String phoneNum,String city,String country){
		name=n;
		am=id;
		phoneNumber=phoneNum;
		cityLiving=city;
		countryLiving=country;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getAm() {
		return am;
	}
	public void setAm(String am) {
		this.am=am;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber){
		this.phoneNumber=phoneNumber;
	}
	public String getCityLiving() {
		return cityLiving;
	}
	public void setCityLiving(String cityLiving) {
		this.cityLiving=cityLiving;
	}
	public String getCountryLiving() {
		return countryLiving;
	}
	public void setCountryLiving(String countryLiving) {
		this.countryLiving=countryLiving;
	}
	
	public abstract void print();
	
	public abstract int getDiscount();
	
	public String toString() {
	return getName()+",ID:"+getAm()+",Phone: +"+getPhoneNumber()+", "+getCityLiving()+","+getCountryLiving();
	}
}
