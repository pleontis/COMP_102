package tuc.ece.cs102.company;

public class Bike extends Passenger{
	BikeProperties property;

	public Bike(String id,String brand,int releaseYear,int km, float cost,int person,int cc,BikeProperties prop) {
		super(id,brand,releaseYear, km, cost, person, cc);
		property=prop;
	}
	public Bike(String id,String brand,int releaseYear,int km, float cost,int person,int cc) {
		super(id,brand,releaseYear, km, cost, person, cc);
	}
	public BikeProperties getProperty() {
		return property;
	}
	public void setProperty(BikeProperties property) {
		this.property=property;
	}
	public String toString() {
		return super.toString()+", "+getProperty();
	}
	public void print() {
		System.out.println("Vehicle>Passenger>Bike:"+this.toString());
	}
}
