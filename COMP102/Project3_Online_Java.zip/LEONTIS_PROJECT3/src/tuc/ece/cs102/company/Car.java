package tuc.ece.cs102.company;

public class Car extends Passenger {
	int doors;
	String type;
	CarProperties property;
	
	public Car(String id,String brand,int releaseYear,int km, float cost,int person,int cc,int d,CarProperties prop, String t){
		super(id,brand,releaseYear,km,cost,person,cc);
		doors=d;
		property=prop;
		type=t;
	}
	
	public Car(String id,String brand,int releaseYear,int km,float cost,int person, int cc,int d,CarProperties prop) {
		super(id,brand,releaseYear,km,cost,person,cc);
		doors=d;
		property=prop;
		
		if(person>7)
			type="DX";
		else
			type="IX";
	}
	public Car(String id,String brand,int releaseYear,int km,float cost,int person,int cc,int d, String t) {
		super(id,brand,releaseYear,km,cost,person,cc);
		doors=d;
		type=t;
	}
	
	public int getDoors() {
		return doors;
	}
	public void setDoors(int doors) {
		this.doors=doors;
	}
	public CarProperties getProperty() {
		return property;
	}
	public void setProperty(CarProperties property) {
		this.property=property;
	}
	public void setPersonCapacity(int pCapacity) {
		
		if(pCapacity>7) {
			setType("DX");	
		}
		else {
			setType("IX");
		}
		
		super.personCapacity=pCapacity;
			
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type=type;
	}
	public void print() {
		System.out.println("Vehicle>Passenger>Car:"+this.toString());
		
	}
	public String toString() {
		return super.toString()+", doors:"+getDoors()+", "+getProperty()+","+getType();
	}
}
