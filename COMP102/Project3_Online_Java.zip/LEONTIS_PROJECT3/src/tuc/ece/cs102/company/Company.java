package tuc.ece.cs102.company;

public class Company extends Client {
	int discount;
	
	public Company(String n,String id,String phoneNum,String city,String country,int dis) {
		super(n,id,phoneNum,city,country);
		discount=dis;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discountPercentage) {
		this.discount=discount;
	}
	public void print() {
		System.out.println("Client>Company"+toString());
	}
	public String toString() {
		return super.toString()+",discount:"+getDiscount()+"%";
	}
}
