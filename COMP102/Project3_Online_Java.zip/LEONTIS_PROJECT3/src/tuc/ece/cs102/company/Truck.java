package tuc.ece.cs102.company;

public class Truck extends Vehicle {
	protected int allowedLoad;
	protected float width, height; 
	
	public Truck(String id,String brand,int releaseYear,int km,float cost,int load,float h,float w) {
		super(id,brand,releaseYear,km,cost);
		allowedLoad=load;
		height=h;
		width=w;
	}
	public int getAllowedLoad() {
		return allowedLoad;
	}
	public void setAllowedLoad(int maxLoad) {
		this.allowedLoad=maxLoad;
	}
	public float getHeight() {
		return height; 
	}
	public void setHeight(float height) {
		this.height=height;
	}
	public float getWidth() {
		return width;
	}
	public void setWidth(float width) {
		this.width=width;
	}
	public void print() {
		System.out.println("Vehicle>Truck:"+toString());
	}
	public String toString() {
		return super.toString()+", allowed load: "+getAllowedLoad()+"kg, height:"+getHeight()+"m, width:"+getWidth()+"m";
	}
}
