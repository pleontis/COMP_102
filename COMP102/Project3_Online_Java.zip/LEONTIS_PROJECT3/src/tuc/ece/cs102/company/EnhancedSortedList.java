package tuc.ece.cs102.company;

import tuc.ece.cs102.list.Item;
import tuc.ece.cs102.list.Node;
import tuc.ece.cs102.list.SortedList;

public class EnhancedSortedList extends SortedList {
	
	public EnhancedSortedList() {
		super();
	}
	public Item search(String key) {
		Node tmpNode=head;
		while(tmpNode!=null) {
			if(tmpNode.getData().key().toString().equals(new String(key))) {
				return tmpNode.getData();
			}
			tmpNode=tmpNode.getNext();
			}
		//Same key wasn't found
		return null;
		}
	public void printAllInHierarchy(String className){
		Node tmp = head;
		try{
			while (tmp!=null){
				Item item = tmp.getData();				
				if (Class.forName(className).isInstance(item.getData())){
					item.print();
				}
				tmp = tmp.getNext();
			}
		}catch (ClassNotFoundException ex){
			System.out.println("This class "+className+" does not exist...");
		}		
	}
}
