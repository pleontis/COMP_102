package tuc.ece.cs102.company;

public enum CarProperties {
 DIESEL, GAS, BATTERY
}
