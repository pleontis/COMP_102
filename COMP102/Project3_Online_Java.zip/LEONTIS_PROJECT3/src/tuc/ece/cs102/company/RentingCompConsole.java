package tuc.ece.cs102.company;

import java.util.Date;

import tuc.ece.cs102.item.ClientItem;
import tuc.ece.cs102.item.RentingItem;
import tuc.ece.cs102.item.VehicleItem;
import tuc.ece.cs102.util.DatePeriod;
import tuc.ece.cs102.util.StandardInputRead;

public class RentingCompConsole {
	private RentingComp renCompany;
	
	public RentingComp getRentingComp() {
		return renCompany;
	}
	public void setRentingComp(RentingComp renCompany) {
		this.renCompany=renCompany;
	}
	private StandardInputRead reader;
	private int menuCase;
	
	public RentingCompConsole() {
		renCompany= new RentingComp();
		reader= new StandardInputRead();
		menuCase=0;
	}
	public static void main(String[] args) {
		
		//Creating a new Company
	RentingCompConsole rConsole=new RentingCompConsole();
	
		//********************************Print Menu to User********************************
		int menuCase=0;
		StandardInputRead reader= new StandardInputRead();
		
		while(menuCase!=11) {
			rConsole.printMenu();
			String userInput=reader.readString("What would you like to do ?");
			if(userInput==null) {
				continue;
			}
			else {
				try {
					menuCase=Integer.parseInt(userInput);
				} catch(NumberFormatException ex) {
					menuCase=0;
				}
			}
			//Variables to create new objects
			String vehicleId, clientId;
			Date d1,d2;
			
			
			switch(menuCase) {
				case 0:
					continue;
				case 1: //Search Vehicle by ID
					vehicleId=reader.readString("Please enter the Vehicle's Id: ");
					Vehicle searchVeh=rConsole.getRentingComp().searchForVehicle(vehicleId);
					if(searchVeh==null) {
						System.out.println("Vehicle with Id: "+vehicleId+" wasn't found");
						reader.readString("Press any key to continue...");
					}
					else {
						searchVeh.print();
						reader.readString("Press any key to continue...");
					}
					break;
				case 2: //Delete Vehicle
					vehicleId=reader.readString("Please enter the Vehicle's Id: ");
					VehicleItem deleteVeh=(VehicleItem) rConsole.getRentingComp().getVehicles().search(vehicleId);
					if(deleteVeh==null) {
						System.out.println("Vehicle with Id: "+vehicleId+" wasn't found");
						reader.readString("Press any key to continue...");
					}
					else {
						rConsole.getRentingComp().getVehicles().delete(deleteVeh);
						System.out.println("Vehicle deleted...");
						reader.readString("Press any key to continue...");
					}
					break;
				
				case 3: //Print all Vehicles
					rConsole.getRentingComp().getVehicles().printList();
					reader.readString("Press any key to continue...");
					break;
				case 4:
					rConsole.printVehiclesByCategory();
					break;
				
				case 5:// Search Client by ID
					clientId=reader.readString("Please enter the Client's Id: ");
					Client searchCl=rConsole.getRentingComp().searchForClient(clientId);
					if(searchCl==null) {
						System.out.println("Client with Id: "+clientId+" wasn't found");
						reader.readString("Press any key to continue...");
					}
					else {
						searchCl.print();
						reader.readString("Press any key to continue...");
					}
					break;
				
				case 6: //Delete Client
					clientId=reader.readString("Please enter the Client's Id: ");
					
					ClientItem deleteCl=(ClientItem) rConsole.getRentingComp().getClients().search(clientId);
					if(deleteCl==null) {
						System.out.println("Client with Id: "+clientId+" wasn't found");
						reader.readString("Press any key to continue...");
					}
					else {
						rConsole.getRentingComp().getClients().delete(deleteCl);
						System.out.println("Client deleted...");
						reader.readString("Press any key to continue...");
					}
					break;
				
				case 7: //Add a new Rental
					int numOfRentals=107;
					//Finding Client
					clientId=reader.readString("Please enter the Client's Id: ");
					Client cl=rConsole.getRentingComp().searchForClient(clientId);
					
					//Finding Vehicle
					vehicleId=reader.readString("Please enter the Vehicle's Id: ");
					Vehicle veh=rConsole.getRentingComp().searchForVehicle(vehicleId);
					
					//Enter dates
					d1=reader.readDate("Please enter renting date(dd/mm/yyyy):");
					d2=reader.readDate("Please enter expiration date(dd/mm/yyyy):");
					
					if(cl==null) {
						System.out.println("Couldn't found Client");
						reader.readString("Press any key to continue...");
						break;
					}
					if(veh==null) {
						System.out.println("Couldn't find Vehicle");
						reader.readString("Press any key to continue...");
					}
					else if((rConsole.getRentingComp().checkForOverlaps(new DatePeriod(d1,d2),veh))){
							System.out.println("This car is already rented in that period");
							reader.readString("Press any key to continue...");
						
							break;
					}
					else {
						
						
						float total= rConsole.getRentingComp().computeTotalCost(veh,cl,new DatePeriod(d1,d2));						
						
						Renting renting=new Renting(108,cl.getName(),veh.getAm(),d1,d2,total);
						rConsole.getRentingComp().addRenting(renting);
						System.out.println("Renting Added...");	
						
						reader.readString("Press any key to continue...");
						break;
						
					}
				case 8: //Print all Rentals
					rConsole.printRentalsByUserOption();
					reader.readString("Press any key to continue...");
					break;
					
				
				case 9: //Add a new Client
					rConsole.addNewVehicle();
					reader.readString("Press any key to continue...");
					break;
				case 10://Add a new Vehicle
					rConsole.addNewClient();
					reader.readString("Press any key to continue...");
					break;
				case 11:
					System.out.println("Thanks for using the Renting Company Console");
					break;
				default:
					System.out.println("User option: "+menuCase+" ignored.");
					continue;
			
			}
		}
	}
	
	public static void printMenu() {
		System.out.println("---------------Renting Company---------------");
		System.out.println("=============================================");
		System.out.println("1)Search a Vehicle by PlateID................");
		System.out.println("2)Delete a Vehicle by PlateID................");
		System.out.println("3)Print all Vehicles.........................");
		System.out.println("4)Search a specific Vehicle Category.........");
		System.out.println("5)Search a Client by Id......................");
		System.out.println("6)Delete a Client............................");
		System.out.println("7)Enter a new Renting........................");
		System.out.println("8)Print all Rentals By Category..............");
		System.out.println("9)Enter a new Vehicle........................");
		System.out.println("10)Enter a new Client........................");
		System.out.println("11)Exit menu...");
		System.out.println("=============================================");
	}
	
	//ADDING NEW ITEM METHODS
	
	public void addNewClient() {
		menuCase=0;
		
		while(menuCase>3 || menuCase<1) {
			System.out.println("=======Insert New Client=======");
			System.out.println("1) Person");
			System.out.println("2) Company");
			System.out.println("3) Cancel");
			
			//Variables for creating items
			menuCase=reader.readPositiveInt(":");
			String id ,name,tel,city,country;
			int discount;
			
			
			switch(menuCase) {
				case 1: //Creating Person
					name=reader.readString("Person's Name: ");
					id=reader.readString("Person's Id: ");
					tel=reader.readString("Person's Telephone Number: ");
					city=reader.readString("City living:");
					country=reader.readString("Country living: ");
					Person p=new Person(name,id,tel,city,country);
					renCompany.addClient(p);
					System.out.println("Person Added...");
					break;
				case 2://Creating Company
					name=reader.readString("Company's Name: ");
					id=reader.readString("Company's Id: ");
					tel=reader.readString("Company's Telephone Number: ");
					city=reader.readString("City: ");
					country=reader.readString("Country: ");
					discount=reader.readPositiveInt("Company's discount percentage: ");
					Company co=new Company(name,id,tel,city,country,discount);
					renCompany.addClient(co);
					System.out.println("Company Added...");
					break;
			case 3:
				break;
			}
			break;
		}
	}
	
	public void addNewVehicle() {
		menuCase=0;
		while(menuCase>3 || menuCase<1) {
			System.out.println("=======Insert New Vehicle=======");
			System.out.println("1) Passenger");
			System.out.println("2) Trucks");
			System.out.println("3) Cancel");
		
			menuCase=reader.readPositiveInt(":");
			//Variables for creating new Items
			String id,brand,type,property;
			int km,person, cc, doors,releaseYear,load;
			float cost,height,width;
		
			switch(menuCase) {
				case 1://Passenger
					int option=0;
					while(option>3 || option<1) {
						System.out.println("1) Car");
						System.out.println("2) Bike");
						System.out.println("3) Cancel");
						option=reader.readPositiveInt(":");
						switch(option) {
							case 1: //Car
								id=reader.readString("Enter Car's Id: ");
								brand=reader.readString("Enter Car's model: ");
								releaseYear=reader.readPositiveInt("Year of release: ");
								km=reader.readPositiveInt("Distance travelled (km): ");
								cost=reader.readPositiveFloat("Enter price: ");
								person=reader.readPositiveInt("Enter person capacity: ");
								cc=reader.readPositiveInt("Enter engine's cubic centimeters(cc): ");
								doors=reader.readPositiveInt("Enter Car's doors: ");
								property=reader.readString("Type Car's Property: 1)DIESEL 2)GAS 3)BATTERY");
							
								System.out.println("------------------------------------------------------------");
								System.out.println("If person capacity is no bigger than 7 type 'IX' else 'DX': ");
								type=reader.readString("Enter type: ");
							
								Car c=new Car(id,brand,releaseYear,km,cost,person,cc,doors,CarProperties.valueOf(property),type);
								renCompany.addVehicle(c);
								System.out.println("Car Added...");
								break;
						
							case 2: //Bike
								id=reader.readString("Enter Bike's Id: ");
								brand=reader.readString("Enter Bike's model: ");
								releaseYear=reader.readPositiveInt("Year of release: ");
								km=reader.readPositiveInt("Distance travelled (km): ");
								cost=reader.readPositiveFloat("Enter price: ");
								person=reader.readPositiveInt("Enter person capacity(Can't be bigger than 2): ");
								cc=reader.readPositiveInt("Enter engine's cubic centimeters(cc): ");
								property=reader.readString("Type Bike's Property: 1)TOURING 2)CRUISER 3)SPORT 4)ON_OFF");
								
								Bike b= new Bike(id,brand,releaseYear,km,cost,person,cc,BikeProperties.valueOf(property));
								renCompany.addVehicle(b);
								System.out.println("Bike Added...");
								break;
						
							case 3:
								break;
					
					}
			}
				break;
				case 2: //Truck
					id=reader.readString("Enter Truck's Id: ");
					brand=reader.readString("Enter Truck's model: ");
					releaseYear=reader.readPositiveInt("Year of release: ");
					km=reader.readPositiveInt("Distance travelled (km): ");
					cost=reader.readPositiveFloat("Enter price: ");
					load=reader.readPositiveInt("Enter max load allowed to carry(kg): ");
					height=reader.readPositiveFloat("Enter Truck's height: ");
					width=reader.readPositiveInt("Enter Truck's width: ");
					
					Truck truck= new Truck(id,brand,releaseYear,km,cost,load,height,width);
					renCompany.addVehicle(truck);
					break;
				case 3:
					break;
		
		}
			break;
		}
		
		
	}
	
	public void printVehiclesByCategory() {
		String category = reader.readString("What kind of Vehicles do you want to see?");
		renCompany.printVehiclesByCategory(category);
	}
	public void printClientsByCategory() {
		String category = reader.readString("What kind of Clients do you want to see?");
		renCompany.printClientsByCategory(category);
	}
	public void printrentalsByCategory() {
		String category = reader.readString("What kind of Vehicles do you want to see?");
		renCompany.printRentalsByCategory(category);
	}
	
	public void printRentalsByUserOption() {
	   	menuCase=0;
		while(menuCase<1 || menuCase>4) {
			System.out.println("What rentals do yo want to see? ");
			System.out.println("1)Print by Vehicle's ID");
			System.out.println("2)Print by Client's ID");
			System.out.println("3)Print by Date Period");
			System.out.println("4)Cancel");
			menuCase=reader.readPositiveInt(":");
			
			String a;
			switch(menuCase) {
				case 1:
					a=reader.readString("Enter Vehicle's ID: ");
				
					if(renCompany.searchForVehicle(a)==null) {
						System.out.println("Vehicle wasn't found");
						break;
					}
					renCompany.printRentalByVehicle(a);
					break;
				
				case 2:
					a=reader.readString("Enter Client's ID");
				
					if(renCompany.searchForClient(a)==null) {
						System.out.println("Client wasn't found");
						break;
					}
				
					renCompany.printRentalByClient(a);
					break;
				case 3:
					Date startD, endD;
					startD=reader.readDate("Give starting date(dd/mm/yyyy): ");
					endD=reader.readDate("Enter ending date(dd/mm/yyyy): ");
					
					renCompany.printRentalByDatePeriod(new DatePeriod(startD,endD));
					break;
				case 4:
					break;
			}
		
		}
	}
}
