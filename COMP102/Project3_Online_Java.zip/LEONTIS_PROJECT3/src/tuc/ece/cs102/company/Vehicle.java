package tuc.ece.cs102.company;

public abstract class Vehicle {
	protected String am;
	protected String model;
	protected int yearOfRelease;
	protected int distanceTravelled;
	protected float price;
	
	public Vehicle(String id,String brand,int releaseYear,int km, float cost) {
		am=id;
		model=brand;
		yearOfRelease=releaseYear;
		distanceTravelled=km;
		price=cost;
	}
	public String getAm() {
		return am;
	}
	public void setAm(String am) {
		this.am=am;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model=model;
	}
	public int getYearOfRelease() {
		return yearOfRelease;
	}
	public void setYearOfRelease(int yearOfRelease) {
		this.yearOfRelease=yearOfRelease;
	}
	public int getDistanceTravelled() {
		return distanceTravelled;
	}
	public void setDistanceTravelled(int distanceTravelled) {
		this.distanceTravelled=distanceTravelled;
	}
	public float getPrice() {
		return price;
	}	
	public void setPrice(float price) {
		this.price=price;
	}
	public String toString() {
		return "["+getAm()+"], "+getModel()+", released:"+getYearOfRelease()+", travelled: "+getDistanceTravelled()+"km, price: "+getPrice()+", ";
	}
	
	public abstract void print();
	
}
