package tuc.ece.cs102.company;

import java.util.Date;

import tuc.ece.cs102.item.ClientItem;
import tuc.ece.cs102.item.RentingItem;
import tuc.ece.cs102.item.VehicleItem;
import tuc.ece.cs102.list.Node;
import tuc.ece.cs102.list.SortedList;
import tuc.ece.cs102.util.DatePeriod;
import tuc.ece.cs102.util.StandardInputRead;

public class RentingComp {
	private String Name;
	private long code;
	private String headquarters;
	private  EnhancedSortedList clients;
	private  EnhancedSortedList rentals;
	private  EnhancedSortedList vehicles;
	
	public RentingComp(){
		Name="Renting Company of Chania";
		code=123456789;
		headquarters="Chania,Greece";
		clients=new EnhancedSortedList();
		rentals=new EnhancedSortedList();
		vehicles=new EnhancedSortedList();
		
		//Adding Some Clients
		clients.insert(new ClientItem(new Person("Nikos Arabatzis","123456789","3028210373","Chania","Greece")));
		clients.insert(new ClientItem(new Person("Johanes Stevenson","987456321","4621097275","Stockhoml","Sweden")));
		clients.insert(new ClientItem(new Company("Nick Malone","741258963","3536975589","Dublin","Ireland",10)));
		clients.insert(new ClientItem(new Company("Tim Roberg","25896314","3265738648","Brussels","Belgium",20)));
	
		//Adding some Vehicles and Properties to Cars and Bikes
		vehicles.insert(new VehicleItem(new Car("XNK5544","Mercedes C200",2012,120000,50,5,1800,4,CarProperties.BATTERY,"IX")));
		vehicles.insert(new VehicleItem(new Car("XNA1204","Honda Pilot",2019,5000,70,7,3000,5,CarProperties.DIESEL,"IX")));
		vehicles.insert(new VehicleItem(new Car("XNM1345","Mercedes MiniBXS",2018,6000,100,12,3000,4,CarProperties.DIESEL,"DX")));
		vehicles.insert(new VehicleItem(new Bike("XNO1706","Yamaha YZF-R3",2015,60500,45,2,600,BikeProperties.TOURING)));
		vehicles.insert(new VehicleItem(new Bike("XNX9901","Kawasaki Ninja 300",2012,32000,30,2,300,BikeProperties.CRUISER)));
		vehicles.insert(new VehicleItem(new Truck("XNA1207","Volvo FH16",2017,90000,250,20000,4,3)));
		vehicles.insert(new VehicleItem(new Truck("XNA1208","Scania XD1",2018,80000,300,25000,3,3)));
		
		//Adding Some Rentals
		rentals.insert(new RentingItem(new Renting(100,"Nikos Arabatzis","XNK5544",new Date("2019/04/03"),new Date("2019/04/22"),950)));
		rentals.insert(new RentingItem(new Renting(101,"Johanes Stevenson","XNA1204",new Date("2019/04/05"),new Date("2019/04/08"),210)));
		rentals.insert(new RentingItem(new Renting(102,"Nick Malone","XNO1706",new Date("2019/06/05"),new Date("2019/06/15"),405)));
		rentals.insert(new RentingItem(new Renting(103,"Tim Roberg","XNX9901",new Date("2019/06/05"),new Date("2019/06/15"),240)));
		rentals.insert(new RentingItem(new Renting(104,"Nikos Arabatzis","XNA1207",new Date("2019/06/06"),new Date("2019/06/14"),2250)));
		rentals.insert(new RentingItem(new Renting(105,"Johanes Stevenson","XNA1208",new Date("2019/06/07"),new Date("2019/06/15"),2400)));
		rentals.insert(new RentingItem(new Renting(106,"Nick Malone","XNK5544",new Date("2019/06/05"),new Date("2019/06/15"),450)));
		rentals.insert(new RentingItem(new Renting(107,"Tim Roberg","XNM1345",new Date("2019/08/05"),new Date("2019/08/15"),800)));
	}
	
		//ADD METHODS
	public void addClient(Client cl) {
		clients.insert(new ClientItem(cl));
	}
	public void addVehicle(Vehicle veh) {
		vehicles.insert(new VehicleItem(veh));
	}
	public void addRenting(Renting ren) {
		rentals.insert(new RentingItem(ren));
	}
		//SEARCH METHODS
	
	public Client searchForClient(String afm) {
		ClientItem cItem= (ClientItem) clients.search(afm);
		//Client with afm wasn't found
		if(cItem==null) {
			return null;
		}
		else {
			return (Client) cItem.getData();}
		}
	
	public Vehicle searchForVehicle(String afm) {
		VehicleItem vItem=(VehicleItem) vehicles.search(afm);
		//Vehicle with afm wasn't found
		if(vItem==null) {
			return null;
		}
		else {
			return (Vehicle) vItem.getData();
		}
	}
	
	public Renting searchForRenting(String afm) {
			RentingItem rItem= (RentingItem)rentals.search(afm);
			
			//Renting with afm was found
			if(rItem!=null) {
				return (Renting) rItem.getData();
			}
			else {
				return null;
			}
	}
		//PRINT METHODS
	
	public void printClientsByCategory(String catClass) {
		clients.printAllInHierarchy(catClass);
	}
	
	public void printVehiclesByCategory(String catClass) {
		vehicles.printAllInHierarchy(catClass);
	}
	public void printRentalsByCategory(String catClass) {
		rentals.printAllInHierarchy(catClass);
	}
	
		//GETTERS
	public EnhancedSortedList getClients() {
		return clients;
	}
	public EnhancedSortedList getVehicles() {
		return vehicles;
	}
	public EnhancedSortedList getRentals() {
		return rentals;
	}
	
	public boolean checkForOverlaps(DatePeriod userPeriod,Vehicle veh) {
		String vehicleId=veh.getAm();
		Node tmp=rentals.getHead();
		
		for(int j=0;j<rentals.getLenght();j++) {
			
			String id=(String) tmp.getData().key().toString();
			
			Renting ren= searchForRenting(id);
			if(ren==null) {
				System.out.println("Renting is null");
			}
			
			//Finding the vehicle which we want
			if(ren.getVehicle().equals(vehicleId)){
			
				DatePeriod per= new DatePeriod(ren.getRentingDate(),ren.getExpirationDate());
			
				if(per.overlaps(userPeriod))
					return true;
			}
				tmp=tmp.getNext();
		}
		return false;
	}
	public float computeTotalCost(Vehicle veh,Client cl,DatePeriod userPeriod) {
			
			float cost=veh.getPrice();
			int discount=cl.getDiscount();
			
			if(discount==0)
				return userPeriod.toDays()*cost;
			
			return cost*userPeriod.toDays()-cost*userPeriod.toDays()*discount/100;
	}
	
	//PRINT RENTALS BY USERS CRITERIA
	
	public void printRentalByVehicle(String id) {
		for(Node tmp=rentals.getHead();tmp!=null;tmp=tmp.getNext()) {
			if(tmp.getData().vehId().equals(id)) {
				tmp.print();
			}
		}
	}
	public void printRentalByClient(String id) {
		for(Node tmp=rentals.getHead();tmp!=null;tmp=tmp.getNext()) {
			if(tmp.getData().clId().equals(id)) {
				tmp.print();
			}
		}
	}
	public void printRentalByDatePeriod(DatePeriod userPeriod) {
		for(Node tmp=rentals.getHead();tmp!=null;tmp=tmp.getNext()) {
			Renting r = searchForRenting(tmp.getData().key().toString());
			if(r.getDatePeriod().getStart().after(userPeriod.getStart()) && r.getDatePeriod().getEnd().before(userPeriod.getEnd())) {
				tmp.print();
			}
		}
	}

		
		
}
	
	
	
	
	

	

