package tuc.ece.cs102.company;

public abstract class Passenger extends Vehicle{
	protected int personCapacity;
	protected int cubicCentimeters;

	public Passenger(String id,String brand,int releaseYear,int km, float cost,int person,int cc) {
		super(id,brand,releaseYear,km,cost);
		personCapacity=person;
		cubicCentimeters=cc;
	}
	public int getPersonCapacity() {
		return personCapacity;
	}
	public void setPersonCapacity(int personCapacity) {
		this.personCapacity=personCapacity;
	}
	public int getCubicCentimeters() {
		return cubicCentimeters;
	}
	public void setCubicCentimeters(int cubicCentimeters) {
		this.cubicCentimeters=cubicCentimeters;
	}
	public String toString() {
		return super.toString()+ getCubicCentimeters()+"cc, "+"Passengers:"+getPersonCapacity();
	}
	
	public abstract void print();
	

}
