package tuc.ece.cs102.company;

public class Person extends Client {
	protected int discount;
	public Person(String n,String id,String phoneNum,String city,String country){
		super(n,id,phoneNum,city,country);
		discount=0;
	}
	
	public void print() {
		System.out.println("Client>Person: "+super.toString());
	}
	public int getDiscount() {
		return discount;
	}
	

}
