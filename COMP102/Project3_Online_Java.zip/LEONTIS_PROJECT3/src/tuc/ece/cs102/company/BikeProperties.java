package tuc.ece.cs102.company;

public enum BikeProperties {
	TOURING, CRUISER, SPORT, ON_OFF;

}
