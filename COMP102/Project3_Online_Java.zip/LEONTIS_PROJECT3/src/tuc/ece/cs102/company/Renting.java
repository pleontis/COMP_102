package tuc.ece.cs102.company;

import java.util.Date;

import tuc.ece.cs102.util.DatePeriod;

public class Renting {
	private int code;
	private String client;
	private String vehicle;
	private Date rentingDate, expirationDate;
	private float totalCost;
	
	public Renting(int c, String cl, String veh,Date rDate, Date expDate,float cost){
		code=c;
		client=cl;
		vehicle=veh;
		rentingDate=rDate;
		expirationDate=expDate;
		totalCost=cost;
	}
	public Renting(int c,String cl,String veh,Date d1,Date d2) {
		code=c;
		client=cl;
		vehicle=veh;
		Date rentingDate=d1;
		Date expirationDate=d2;	
	}
	
	public int getCode() {
		return code;
	}
	public void setCode(int code){
		this.code=code;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client=client;
	}
	public String getVehicle() {
		return vehicle;
	}
	public void setVehicle(String vehicle) {
		this.vehicle=vehicle;
	}
	public Date getRentingDate() {
		return rentingDate;
	}
	public void setRentingDate(Date rentingDate) {
		this.rentingDate=rentingDate;
	}
	public Date getExpirationDate() {
		return expirationDate; 
	}
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate=expirationDate;
	}
	public float getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(Float totalCost){
		this.totalCost=totalCost;
	}
	public String toString() {
		return "["+getCode()+"]"+", Client:"+getClient()+", Vehicle:"+getVehicle()+", From: "+getRentingDate()+" To:"+getExpirationDate()+", Cost: "+getTotalCost();
	}
	public void print() {
		System.out.println(toString());
	}
	
	public DatePeriod getDatePeriod() {
		return new DatePeriod(getRentingDate(),getExpirationDate());
	}
}
