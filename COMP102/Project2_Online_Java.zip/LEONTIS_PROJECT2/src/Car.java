
import java.util.Vector;
import tuc.ece.cs102.util.StandardInputRead;



public class Car {
	private String plateId;
	private String model;
	private int releaseYear;
	private float averageConsume;
	private int distance;
	private float price;
	private Vector <Properties> listOfProperties;
	
	
	public Car(String id,String m,int release,float avg,int km,float p) {
		plateId=id;
		model=m;
		releaseYear=release;
		averageConsume=avg;
		distance=km;
		price=p;
		listOfProperties=new Vector<Properties>();
		
	}
public String getPlateId() {
	return plateId;
}
public void setPlateId(String plateId) {
	this.plateId=plateId;
}
public String getModel() {
	return model;
}
public int getReleaseYear() {
	return releaseYear;
}
public void setReleaseYear(int releaseYear) {
	this.releaseYear=releaseYear;
}
public float getAverageConsume() {
	return averageConsume;
}
public void setAverageConsume(float averageConsume) {
	this.averageConsume=averageConsume;
}
public float getDistance() {
	return distance;
}
public void setDistance(int distance) {
	this.distance=distance;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price=price;
}
public Vector<Properties> getListOfProperties(){
	return listOfProperties;
}

public void addProperty(Properties properties) {
	listOfProperties.add(properties);
}
public void addNewProperty(int num){

	switch (num) {
	case 1:
		addProperty(Properties.FOUR_WHEEL_DRIVE);
		break;
	case 2:
		addProperty(Properties.DIESEL);
		break;
	case 3:
		addProperty(Properties.HYBRID);
		break;
	case 4:
		addProperty(Properties.AUTOMATIC);
		break;
	case 5:
		addProperty(Properties.CABRIOLET);
		break;
	case 6:
		addProperty(Properties.SEVEN_SEATS);
		break;
	case 7:
		addProperty(Properties.AIR_CONDITION);
		break;
	case 8:
		addProperty(Properties.LEATHER_SEATS);
	break;
	default:
		System.out.println("User option: "+ num +" ignored.");
		
	}
			
}


public String getCarInfo() {
	return "["+getPlateId()+"]"+","+getModel()+", Release Year:"+getReleaseYear()+", Distance:"+getDistance()+", Price:"+getPrice()+", AVG Consume:"+getAverageConsume()+", Properties"+getListOfProperties();
}


}
