import java.util.Date;

import tuc.ece.cs102.util.DatePeriod;
import tuc.ece.cs102.util.StandardInputRead;
import tuc.ece.cs102.util.stringToDate;


public class CompanyConsole {

	public static void main(String[] args) {
		
		
		/*Create a new Company */
		RentingCompany company=new RentingCompany("Leontis Company","123456789","Chania Crete");
		
		/*Adding some new Clients*/
		company.addClient(new Client("Nikos","Arabatzis","RPS442",3,"Greece"));
		company.addClient(new Client("Johanes","Stevenson","RFF839",12,"Sweden"));
		company.addClient(new Client("Katerina","Mpampinioti","HK6689",2,"Greece"));
		company.addClient(new Client("Marilena","Karopoulou","PK0967",5,"Greece"));
		company.addClient(new Client("NIck","Malone","JFK8FR",14,"Ireland"));
		company.addClient(new Client("Tim","Roberg","HJK31F",9,"Belgium"));
		company.addClient(new Client("Mario","Marcelano","ITF934",6,"Italy"));
		company.addClient(new Client("Mantalena","Paliarini","ITJ798",3,"Italy"));
		company.addClient(new Client("Klaus","Regling","DEF987",18,"Germany"));
		company.addClient(new Client("Manousos","Manousaki","GR0912",20,"Greece"));
		
		/*Adding some new Cars*/
		company.addCar(new Car("XNK5544","Ford Fiesta",2012,6.4f,120000,33));
		company.addCar(new Car("XNA1204","Opel Corsa",2015,4.7f,80000,45));
		company.addCar(new Car("XNO1706","Nissan Micra",2015,5.0f,60500,45));
		company.addCar(new Car("XNX9901","Lancia Ypsilon",2012,3.5f,32000,30));
		company.addCar(new Car("XNA1207","Toyota Yaris",2017,2.7f,17000,50));
		company.addCar(new Car("XNA1208","Nissan Qashqai",2015,6.8f,80000,60));
		company.addCar(new Car("XNA1209","Ford Mustang",2015,4.7f,80000,60));
		company.addCar(new Car("XNH1210","Opel Corsa",2018,3.6f,500,80));
		company.addCar(new Car("HKZ1211","Toyota Aygo",2018,3.2f,6000,45));
		company.addCar(new Car("MHO1212","Audi A3",2015,6.1f,33000,58));
		
		/*Adding Properties to Cars*/
		
		Car c1=company.findCarById("XNK5544");
		c1.addProperty(Properties.AIR_CONDITION); c1.addProperty(Properties.DIESEL);
		Car c2=company.findCarById("XNA1204");
		c2.addProperty(Properties.AIR_CONDITION);c2.addProperty(Properties.DIESEL);c2.addProperty(Properties.LEATHER_SEATS);
		Car c3=company.findCarById("XNO1706");
		c3.addProperty(Properties.DIESEL);c3.addProperty(Properties.CABRIOLET);c3.addProperty(Properties.LEATHER_SEATS);
		Car c4 =company.findCarById("XNX9901");
		c4.addProperty(Properties.AIR_CONDITION);c4.addProperty(Properties.DIESEL);c4.addProperty(Properties.AUTOMATIC);
		Car c5=company.findCarById("XNA1207");
		c5.addProperty(Properties.AIR_CONDITION);c5.addProperty(Properties.HYBRID);c5.addProperty(Properties.AUTOMATIC);
		Car c6=company.findCarById("XNA1208");
		c6.addProperty(Properties.SEVEN_SEATS);c6.addProperty(Properties.DIESEL);c6.addProperty(Properties.FOUR_WHEEL_DRIVE);
		Car c7=company.findCarById("XNA1209");
		c7.addProperty(Properties.AIR_CONDITION);c7.addProperty(Properties.AUTOMATIC);c7.addProperty(Properties.LEATHER_SEATS);
		Car c8=company.findCarById("XNH1210");
		c8.addProperty(Properties.AUTOMATIC);c8.addProperty(Properties.AIR_CONDITION);c8.addProperty(Properties.LEATHER_SEATS);
		Car c9=company.findCarById("HKZ1211");
		c9.addProperty(Properties.AIR_CONDITION);c9.addProperty(Properties.DIESEL);c9.addProperty(Properties.AUTOMATIC);
		Car c10=company.findCarById("MHO1212");
		c10.addProperty(Properties.AIR_CONDITION);c10.addProperty(Properties.AUTOMATIC);c10.addProperty(Properties.LEATHER_SEATS);
		
		/*Adding some new Rentals*/
		stringToDate d1=new stringToDate();
		stringToDate d2=new stringToDate();
		
		company.addRenting(new Renting(100,company.findClientById("RPS442"),company.findCarById("XNX9901"),d1.getDate("03/04/2019"),d2.getDate("22/04/2019"),570.0f ));
		company.addRenting(new Renting(101,company.findClientById("RFF839"),company.findCarById("XNA1207"),d1.getDate("05/04/2019"),d2.getDate("08/04/2019"),150.0f));
		company.addRenting(new Renting(102,company.findClientById("HK6689"),company.findCarById("XNA1208"),d1.getDate("05/06/2019"),d2.getDate("15/06/2019"),600.0f));
		company.addRenting(new Renting(103,company.findClientById("PK0967"),company.findCarById("XNA1209"),d1.getDate("05/06/2019"),d2.getDate("15/06/2019"),450.0f));
		company.addRenting(new Renting(105,company.findClientById("HJK31F"),company.findCarById("HKZ1211"),d1.getDate("07/06/2019"),d2.getDate("15/06/2019"),360.0f));
		company.addRenting(new Renting(106,company.findClientById("ITF934"),company.findCarById("MHO1212"),d1.getDate("05/06/2019"),d2.getDate("15/06/2019"),464.0f));
		company.addRenting(new Renting(107,company.findClientById("RPS442"),company.findCarById("XNX9901"),d1.getDate("03/05/2019"),d2.getDate("19/05/2019"),384.0f));
		company.addRenting(new Renting(108,company.findClientById("PK0967"),company.findCarById("XNA1207"),d1.getDate("07/07/2019"),d2.getDate("12/07/2019"),225.0f));
		company.addRenting(new Renting(109,company.findClientById("PK0967"),company.findCarById("XNX9901"),d1.getDate("07/06/2019"),d2.getDate("15/06/2019"),192.0f));
		
		
		
		
		/******************************PRINT MENU TO USER**************************/
	int option=0;
	StandardInputRead reader=new StandardInputRead();
	while(option!=6) {	
		printMenu();
	
		String userInput= reader.readString("What would you like to do ? ");
		if(userInput==null) {
			continue;
		}
		else {
			try {
				option=Integer.parseInt(userInput);
			} catch(NumberFormatException ex) {
				option=0;
			}
		}
		/*Variables to create new objects*/
		
		String fName,lName,clientId,nationality,model,exit="yes";
		String carId;
		int years,release,km,choice;
		float avg,price;
		int r=1;
		
		Date rDate= new Date();
		Date expDate= new Date();
		
		int listSize=0;
		
		
		
		switch (option) {
			case 0:
				continue;
			case 1:
				carId=reader.readString("Enter Plate Id: ");
				model=reader.readString("Enter model: ");
				release=reader.readPositiveInt("Enter year of release: ");
				avg=reader.readPositiveFloat("Enter average consume of fuel: ");
				km=reader.readPositiveInt("Enter distance gone in km: ");
				price=reader.readPositiveFloat("Enter price: ");
				
				company.addCar(new Car(carId,model,release,avg,km,price));
				Car c=company.findCarById(carId);
				while( exit.equals("yes")){
					exit=reader.readString("Do you want to add a property? (yes/no): ");
				
					if(exit.equals("yes")){
						System.out.println("1)FOUR_WHEEL_DRIVE,2)DIESEL,3)HYBRID,4)AUTOMATIC,5)CABRIOLET,6)SEVEN_SEATS,7)AIR_CONDITION,8)LEATHER_SEATS");
						choice=reader.readPositiveInt("Pick a number for your Car's property: ");
						c.addNewProperty(choice);
					}
					else {
						System.out.println("Car has been added");
						reader.readString("Press any key to contiue...");
					}
				}
				break;
			
			case 2:
				company.printCars(); 
				reader.readString("Press any key to contiue...");
				
				break;

			case 3:
				clientId=reader.readString("Enter license id: ");
				fName=reader.readString("Enter first name: ");
				lName=reader.readString("Enter last name: ");
				nationality=reader.readString("Client is from: ");
				years=reader.readPositiveInt("Years of driving");
				company.addClient(new Client(fName,lName,clientId,years,nationality));		
				
				reader.readString("Press any key to contiue...");
				break;
			case 4:
				listSize++;
				
				carId=reader.readString("Enter Car's Id: ");
				clientId=reader.readString("Enter Client's license Id: ");
				rDate=reader.readDate("Enter renting Date (dd/mm/yyyy): ");
				expDate=reader.readDate("Enter expiration Date (dd/mm/yyyy): ");
				Car car=company.findCarById(carId);
				
				Client client=company.findClientById(clientId);
				
				/*Checking for client,car the user typed*/
				if(car==null) {
					System.out.println("Car wasn't found"); 
					break;
				}
				if(client==null) {
					System.out.println("Client wasn't found"); 
					break;
				}
				
				if(company.checkForOverlaps(new DatePeriod(rDate,expDate))) {
					System.out.println("This car is already rented in that period!!!");
					reader.readString("Press any key to contiue...");
					break;
				}
				company.addRenting(new Renting((109+listSize),client,car,rDate,expDate));
				
				Renting renting=company.findRentingById((109+listSize));
				
				if(renting==null) {
					System.out.println("Error during the proccess. Can not add this renting");
					break;
				}
				
				float total=company.computeTotalCost(renting);
				
				renting.setTotalCost(total);
				System.out.println("Renting has been added");
				reader.readString("Press any key to contiue...");
				break;
			case 5:
				company.printRentals();

				reader.readString("Press any key to contiue...");
				break;
			case 6:
				System.out.println("Thanks for using the Renting Company Console");
				break;
			default:
				System.out.println("User option: "+ option+" ignored.");
				continue;
		}
	}
		
			
	}
	public static void printMenu() {
		System.out.println("                      Car Renting Company");
		System.out.println("===============================================================");
		System.out.println("1 Enter a new car..............................................");
		System.out.println("2.Print all Cars...............................................");
		System.out.println("3.Enter a new Client...........................................");
		System.out.println("4.New Renting..................................................");
		System.out.println("5.Print all Rentals............................................");
		System.out.println("6.Exit menu....................................................");
		System.out.println("===============================================================");
	}
}
