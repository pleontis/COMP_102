
public class Client {
	private String firstName, lastName;
	private String licenseId;
	private int yearsOfDriving;
	private String country;

public Client(String fn, String ln,String id,int years,String nationality){
	licenseId=id;
	firstName=fn;
	lastName=ln;
	yearsOfDriving=years;
	country=nationality;
}
public String getLicenseId() {
	return licenseId;
}
public void setLicenseId(String licenseId) {
	this.licenseId=licenseId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName=firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName=lastName;
}
public int getYearsOfDriving() {
	return yearsOfDriving;
}
public void setYearsOfDriving(int yearsOfDriving) {
	this.yearsOfDriving=yearsOfDriving;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country=country;
}
public String getFullName() {
	return getFirstName()+""+getLastName();
}
}