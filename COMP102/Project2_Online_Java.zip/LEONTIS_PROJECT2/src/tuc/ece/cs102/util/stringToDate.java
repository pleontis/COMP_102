package tuc.ece.cs102.util;
import java.text.SimpleDateFormat;
import java.util.Date;
public class stringToDate {
	public Date getDate(String D) {
		try {
			String sd=D;
			Date date=new SimpleDateFormat("dd/MM/yyyy").parse(sd);
		return date;
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			Date dat=new Date(0);
			return dat;
		}
	}
}
