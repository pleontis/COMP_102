import java.util.Date;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

import tuc.ece.cs102.util.DatePeriod;
import tuc.ece.cs102.util.StandardInputRead;

import tuc.ece.cs102.util.StandardInputRead;
public class RentingCompany {
	private String name;
	private String taxNumber;
	private String headquarters;
	private Vector<Car> listOfCars;
	private Vector<Client> listOfClients;
	private Vector<Renting> listOfRentals;
	private Vector<Properties> listOfProperties;
	
	public RentingCompany(String n,String taxN,String hq ) {
		name=n;
		taxNumber=taxN;
		headquarters=hq;
		listOfCars=new Vector<Car>();
		listOfClients=new Vector<Client>();
		listOfRentals=new Vector<Renting>();
		listOfProperties=new Vector<Properties>();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getTaxNumber() {
		return taxNumber;
	}
	public void setTaxNumber(String taxNumber) {
		this.taxNumber=taxNumber;
	}
	public String getHeadquarters() {
		return headquarters;
	}
	public Vector<Client> getListOfClients(){
		return listOfClients;
	}
	public Vector<Car> getListOfCars(){
		return listOfCars;
	}
	public Vector<Renting> getListOfRentals(){
		return listOfRentals;
	}
	public void addRenting(Renting r){
	listOfRentals.add(r);
	}
	public void addCar(Car c) {
		listOfCars.add(c);
	}
	public void addClient(Client c) {
		listOfClients.add(c);
	}

	public void printCars() {
		for(int i=0;i<listOfCars.size();i++) {
			System.out.println(i+")"+listOfCars.get(i).getCarInfo()); 
			}
	}
	public void printRentals(){
		for(int i=0;i<listOfRentals.size();i++) {
		System.out.println(listOfRentals.get(i).getRentingInfo());
		}
	}
	
	
	public Car findCarById(String id) {
		for(int i=0;i<listOfCars.size();i++) {
			Car c=listOfCars.get(i);
			if(id.equals(c.getPlateId())) {
				return c;
			}
		
		}
		return null;
	}
	
	public Client findClientById(String id){
		for(int i=0;i<listOfClients.size();i++) {
			Client c=listOfClients.get(i);
			if(id.equals(listOfClients.get(i).getLicenseId())) {
				return c;
			}
		}
		return null;
	}
	public Renting findRentingById(int am) {
		for(int i=0;i<listOfRentals.size();i++) {
			Renting r=listOfRentals.get(i);
			if(am==listOfRentals.get(i).getAm()) {
				return r;
			}
		}
		return null;
	}

	
	public boolean checkForOverlaps(DatePeriod usersPeriod) {
	 	for(int j=0;j<listOfRentals.size();j++) {
	 		Renting r= listOfRentals.get(j);
	 		DatePeriod per=new DatePeriod(r.getRentingDate(),r.getExpirationDate());
	 	if(usersPeriod.overlaps(per))
	 		return true;
	 	}
	 	return false;
	
	}
	public float computeTotalCost(Renting r) {
		StandardInputRead reader=new StandardInputRead();
		String choice;
		int discount;
		choice=reader.readString("Do yo want to make any discount in price?(yes/no): ");
		DatePeriod period= new DatePeriod(r.getRentingDate() , r.getExpirationDate());
		
		if(choice.equals("no")) {
			return  (r.getCar().getPrice()*period.toDays()); 
		}
		else {
			
			discount=reader.readPositiveInt("Enter discount (%): ");
			if(discount==0) {
				return (r.getCar().getPrice()*period.toDays());
			}
			return  (r.getCar().getPrice()* period.toDays() * (discount/100));
		}
			
		}
}



