
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import tuc.ece.cs102.util.StandardInputRead;

import tuc.ece.cs102.util.DatePeriod;

public class Renting {
	private int am;
	private Client client;
	private Car car;
	private Date rentingDate;
	private Date expirationDate;
	private float totalCost;
	

	public Renting(int id,Client cl,Car c,Date rDate,Date expDate){
		am=id;
		client=cl;
		car=c;
		rentingDate=rDate;
		expirationDate=expDate;
		 
		
	}
	public Renting(int id,Client cl,Car c,Date rDate,Date expDate,float total) {
		am=id;
		client=cl;
		car=c;
		rentingDate=rDate;
		expirationDate=expDate;
		totalCost=total;
		
	}
	public int getAm() {
		return am;
	}
	public void setAm(int am) {
		this.am=am;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client=client;
	}
	public Car getCar() {
		return car;
	}
	public void setCar(Car car) {
		this.car=car;
	}
	public Date getRentingDate() {
		return rentingDate;
	}
	public void setRentingDate(Date rentingDate) {
		this.rentingDate=rentingDate;
	}
	public Date getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate=expirationDate;
	}
	public float getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(float totalCost) {
		this.totalCost=totalCost;
	}
	
	/* Getting as String the Renting Period*/
	public String getRentingPeriod(){
		
		String result = "";
		result += "From: ";
		result += this.rentingDate.toString();
		result += " Until: ";		
		result += this.expirationDate.toString();
		return result;

	}
	public String getRentingInfo() {
		return "["+getAm()+"]"+",Car "+ getCar().getPlateId()+",Client "+ getClient().getLicenseId()+", "+ getRentingPeriod() +", Total Cost:"+ getTotalCost();
	}
	
	
			
	
}


